var searchData=
[
  ['update',['UPDATE',['../class_m_d___m_a_x72_x_x.html#a7c6d702fe0161b19448f35049e00bf4fa6e9fa4baa13700cb81d9ca48d849d26f',1,'MD_MAX72XX::UPDATE()'],['../class_m_d___m_a_x72_x_x.html#a3f91498bfc0023f67d4bf1284ca70317',1,'MD_MAX72XX::update(controlValue_t mode)'],['../class_m_d___m_a_x72_x_x.html#a4d51360880d7a6fa33a6f917cf423879',1,'MD_MAX72XX::update(void)'],['../class_m_d___m_a_x72_x_x.html#a9cc242e22748229a223851217b76fd4e',1,'MD_MAX72XX::update(uint8_t buf)']]],
  ['use_5flocal_5ffont',['USE_LOCAL_FONT',['../_m_d___m_a_x72xx_8h.html#a156ea396ee2a9dd550bc3a78ce65162b',1,'MD_MAX72xx.h']]]
];
